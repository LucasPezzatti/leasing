<?php
/* VERSION NOTES */
?>
<center><b style="color:black">Alterações Recentes:</b><br></center>
<p style="font-size:14px;color:black">
				- Incluido <b> Relatório Mensal De Movimento</b>.<br>
				- Incluido <b> Relatório De Títulos a Vencer </b>.<br>
				- Incluido <b> Relatório De Títulos Vencidos  </b>.<br>
				- Incluido Relatório <b> Resumo De Pendências Por Cedente  </b>.<br>
				- Incluído alerta de valor vencido ao iniciar uma nova <b> Operação </b>.<br>
				- Incluída POPUP com informação do Cedente na linha do título a baixar na tela <b>Controle De Baixa</b>.<br>
				- Incluído Relatório "Resumo por Pessoa" no <b>Cadastro De Pessoa</b>.<br>
				- Incluída a baixa de títulos em lote no <b>Controle De Baixa</b>.<br>
				- Incluído totalizadores no <b> Relatório De Títulos a Vencer</b>.<br>
				- Incluído totalizadores no <b> Relatório De Títulos Vencidos</b>.<br>
				<center><hr><b style="color:black">Novo Na Versão <?php echo $version;?> </b><br></center>
				<span style="color:black">
			
				- Incluído busca de endereço por <b> API </b> no <b> Cadastro De Pessoas</b>.<br>
				
				