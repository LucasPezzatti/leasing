<?php
	  $pdom = new PDO("mysql:host=localhost;dbname=u875229905_leasing_dev;charset=utf8", "u875229905_leasing_dev", "@L@ires_23");
?>
