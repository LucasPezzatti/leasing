<div class="row">
	 <div  class="col-12 col-lg-12">
	   <div id="relatorio" class="card printcolor">
	     <div class="card-header printcolor" style="text-align:center;font-size:22px;border-bottom:0px;!important"> Relatório 'REL. <?= $_GET['relatorio']?>' Não Encontrado. Entre Em Contato Com o Suporte Técnico.<br>