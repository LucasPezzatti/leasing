<?php
//APP 
$appname="Leasing";
//Version Controller
$version="0.9.789";
$copyright="©".date('Y')." | Loires Informática";
?>